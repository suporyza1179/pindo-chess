# ONLINE-CHESS-GAME

 👉🏻 It is an online chess game where players can play against each other in real-time.
 
 >[Play Chess!](https://onlinechess-game.herokuapp.com)
 
 >[Project Demo](https://youtu.be/CCbrTQwYyE8)


## Authors
  
   - **[Amey Thakur](https://github.com/Amey-Thakur)**
   
   - **[Mega Satish](https://github.com/msatmod)**

#
 
### Features

 - [X] Single Player Mode
 
 - [X] Multi-Player Mode
 
 - [X] Multiple Chessboard Themes
 
 - [X] Real-Time Chatting With Opponent
 
 - [X] Sound on Move

---

>**WEB APPLICATION - https://onlinechess-game.herokuapp.com**

![image](https://user-images.githubusercontent.com/54937357/160670075-ec91172a-fcf4-4bed-b8f9-c5b98ab65a6e.png)

---

<p align="center"> <b> 👉🏻 Presented as a part of the 8th Semester Mini-Project @ Terna Engineering College 👈🏻 <b> </p>

<p align="center"> <b> 👷 Project Authors: Amey Thakur and Mega Satish (Batch of 2022) <b> </p>
 
<p align="center"><a href='https://github.com/Amey-Thakur/COMPUTER-ENGINEERING', style='color: greenyellow;'> ✌🏻 Back To Engineering ✌🏻</p>
